# AttackIQ INFORM Assessment Plugin

## Overview
A WordPress plugin that provides an interactive self-assessment tool for measuring an organization's Threat-Informed Defense (TID) maturity. Based on MITRE's INFORM Assessment framework, it evaluates capabilities across three key dimensions and generates actionable insights.

**Version:** 1.1.0
**Author:** Volume11
**Technology Stack:** WordPress Plugin (PHP) + React Frontend

## Quick Reference

### Key Files
| File | Purpose |
|------|---------|
| `attackiq-inform-assessment.php` | Main plugin file, shortcode registration, WP settings |
| `src/components/WizardWrapper.js` | Main React component, tab navigation, results display, score breakdown |
| `src/components/ImpactComplexityMatrix.js` | Impact/Complexity Matrix grid with hover tooltips and section color coding |
| `src/components/QuestionBlock.js` | Individual question rendering with N/A option |
| `src/components/RadarChart.js` | Radar chart visualization |
| `src/components/MarketoModal.js` | Marketo form modal for gated downloads |
| `src/context/AssessmentContext.js` | React state management (answers, step navigation) |
| `src/utils/scoring.js` | Core scoring algorithms + impactComplexityMap generation |
| `src/utils/pdfGenerator.js` | PDF report generation |
| `src/utils/jsonGenerator.js` | MITRE-format JSON export |
| `src/utils/api.js` | REST API submission helper |
| `src/data/inform-component-all-data.json` | Assessment questions data (90+ questions) |
| `src/style.css` | All styling (tooltips, modals, layout, etc.) |
| `includes/class-aiq-api.php` | REST API endpoints for submissions |
| `includes/class-aiq-submission.php` | Custom post type for storing results |

### Build Commands
```bash
cd /Users/bunny/Local\ Sites/attackiq/app/public/wp-content/plugins/attackiq-inform-assessment
npm run build    # Production build
npm run start    # Development with hot reload
```

### WordPress Shortcode
```
[inform_assessment]
[inform_assessment marketo_form_id="1234" gate_downloads="yes"]
```

## Architecture

### Assessment Structure

**Three Dimensions:**
1. **CTI (Cyber Threat Intelligence)** - Weight: 35%
   - 7 components (CTI.1 - CTI.7)
   - Component weights sum to 1.0

2. **DM (Defensive Measures)** - Weight: 40%
   - 10 components (DM.1 - DM.10)

3. **TE (Test & Evaluation)** - Weight: 25%
   - 5 components (TE.1 - TE.5)

**Question Types:**
- `Checkboxes` (multiselect) - Multiple choices can be selected, points sum up
- `Radio Buttons` (select) - Single choice, max points = highest option

### Scoring Algorithm

```javascript
// Per-question score (1-5 scale):
questionScore = (totalPoints / possiblePoints) * 5

// Per-section score:
sectionScore = Σ(questionScore * componentWeight) / Σ(componentWeights)
// Only includes applicable (non-N/A) questions

// Overall score:
overallScore = (CTI_ratio * 0.35) + (DM_ratio * 0.40) + (TE_ratio * 0.25)
// Where ratio = sectionTotalPoints / sectionPossiblePoints

// Score to level mapping:
// 0     -> 0 (None)
// ≤0.2  -> 1 (Initial)
// ≤0.4  -> 2 (Developing)
// ≤0.6  -> 3 (Defined)
// ≤0.8  -> 4 (Managed)
// ≤1.0  -> 5 (Optimized)
// <0    -> -1 (N/A)
```

### N/A (Not Applicable) Handling
- Questions can be marked as "Not Applicable" by users
- Answer stored as string `'N/A'` instead of array of indices
- N/A questions are excluded from scoring calculations
- N/A questions have `totalPoints: -1`, `possiblePoints: 0`, `isNotApplicable: true`
- If all questions in a section are N/A, section score returns -1

### State Management

**AssessmentContext Actions:**
- `NEXT_STEP` - Advance to next tab
- `PREV_STEP` - Go to previous tab
- `GO_TO_STEP` - Navigate directly to any tab (for clickable tabs)
- `RESET` - Clear all answers, return to step 0
- `SET_ANSWER` - Store answer for a question

**Answer Format:**
```javascript
answers: {
  'CTI.1': [0, 2, 3],     // Array of selected choice indices
  'CTI.2': 'N/A',          // String for Not Applicable
  'DM.3': [1],             // Single selection for radio buttons
}
```

## Data Structure

### Question Data (inform-component-all-data.json)
```json
{
  "UID": "CTI.1.1",
  "Dimension": "Cyber Threat Intelligence",
  "Dimension ID": "CTI",
  "Dimension Weight": 0.35,
  "Component": "Depth of Threat Intelligence",
  "Component ID": 1,
  "Component Weight": 0.25,
  "Question": "What level of intelligence...",
  "Level Description": "Ephemeral IOCs",
  "Level ID": 1,
  "Question Type": "Checkboxes",
  "Impact": 3,
  "Complexity": 1,
  "Points": 1.0
}
```

### Results Structure (processResults output)
```javascript
{
  scoresBySection: [
    {
      section_id: "CTI",
      name: "Cyber Threat Intelligence",
      questions: [...],
      totalPoints: 15,
      possiblePoints: 45,
      applicableCount: 5,
      notApplicableCount: 2
    }
  ],
  overallScore: 0.67,  // 0-1 range
  impactComplexityMap: Map  // For matrix visualization
}
```

## Features

### 1. Multi-step Wizard
- 4 tabs: CTI, DM, TE, Results
- Clickable tabs for direct navigation
- Auto-scroll to top on tab change
- Progress tracking

### 2. Results Display
- Score breakdown by section and component
- Impact/Complexity Matrix for prioritization (3x3 grid: Impact vs Complexity)
- Hover tooltips on matrix items showing component name + description
- "Great Job!" hover tooltip on max-score items (5 ✓) in score breakdown
- Warning (⚠) tooltip on skipped/unanswered components
- Info (i) tooltip on N/A components
- Maturity level reference table (highlights current level)
- PDF and JSON download options (optionally gated by Marketo form)

### 3. Marketo Integration
- Optional form gating for downloads
- Lead capture with assessment scores
- Configurable via WP admin settings

### 4. CTA Configuration
- Customizable contact button URL and text
- Displayed on results page

## Admin Settings (WP Dashboard)
- Settings > INFORM Assessment
- Marketo Form ID, Instance, Munchkin ID
- Gate Downloads toggle
- Contact URL and Button Text

## Reference Materials
Located in `/Users/bunny/Local Sites/attackiq/project-data/`:
- `inform_best_practices_tool.txt` - Original MITRE Vue.js implementation
- `inform-schema.json` - JSON schema for assessment downloads
- `inform-component-all-data.json` - Question data
- `AIQ-Edits-3 - inform-components-12NOV2025 - Copy.xlsx` - Component data spreadsheet
- `Email Chain.docx` - Client requirements and communications

## Section Color Scheme

Colors are used consistently across section headers (WizardWrapper.js `sectionColors`) and matrix items (ImpactComplexityMatrix.js `sectionColorMap`):

| Section | Header/Highest BG | Highest Text | Selected BG | Selected Text |
|---------|-------------------|-------------|-------------|---------------|
| CTI | `#ffcc00` (yellow) | `#000` | `#fff3cc` | `#8a6d00` |
| DM | `#36bae4` (blue) | `#000` | `#d6f0fa` | `#1a6e8a` |
| TE | `#f02c68` (pink) | `#fff` | `#fdd6e3` | `#a01040` |

**Matrix item states:**
- **Selected + Highest** → Full section color + checkmark (✓)
- **Selected (not highest)** → Light/pastel section color + solid border
- **Unselected/Suggested** → White background + gray dashed border

## Tooltip/Popup System

Two tooltip patterns are used:

### 1. CSS `data-tooltip` pattern (score breakdown icons)
Used by `.aiq-warning-icon`, `.aiq-na-info-icon`, `.aiq-max-score-icon` in `style.css`.
Uses `::after` pseudo-element with `content: attr(data-tooltip)`. Pure CSS, no JS state needed.

### 2. React state-based tooltips (matrix items)
Used in `ImpactComplexityMatrix.js`. Tracks `hoveredItem` via `useState`.
Renders a positioned `<div className="aiq-matrix-tooltip">` on hover.
Styled via `<style jsx>` block inside the component.

Both use the same visual style: `#f5f5f5` background, `#ddd` border, `0 2px 8px` shadow.

## Impact/Complexity Map Data

Generated by `scoring.js` `addToMap()` helper. Each matrix item contains:
```javascript
{
  componentKey: "CTI.1",        // Section + Component ID
  uid: "CTI.1.1",              // Full UID for display
  heading: "Depth of...",      // Component name
  choiceDescription: "...",    // Level description text
  impact: 3,                   // 1-3 (row in matrix)
  complexity: 1,               // 1-3 (column in matrix)
  selected: true,              // User selected this level
  highestValue: true,          // Represents max possible score
  empty: false                 // User hasn't answered this question
}
```

Map keys follow pattern `"i-{impact}_c-{complexity}"` (e.g., `"i-3_c-1"` = High Impact, Low Complexity).

## Common Tasks

### Adding a New Question Type
1. Update `inform-component-all-data.json`
2. Modify `QuestionBlock.js` if new input type needed
3. Update `scoring.js` point calculation logic

### Modifying Scoring Algorithm
Edit `src/utils/scoring.js`:
- `processResults()` - Main scoring pipeline
- `calculateSectionScore()` - Section-level scoring
- `getScoreLabel()` - Score to label mapping

### Changing Tab Navigation
Edit `src/components/WizardWrapper.js`:
- `sections` array defines tab order
- `sectionLabels` defines display names
- Tab click handler around line 288

### Changing Section Colors
**Section headers** (score breakdown): Edit `WizardWrapper.js` → `sectionColors` object (~line 399).
**Matrix items**: Edit `ImpactComplexityMatrix.js` → `sectionColorMap` object (top of component).
**Matrix Key legend**: Also in `ImpactComplexityMatrix.js` → the JSX at the bottom of the return.
Keep all three in sync when changing colors.

### Adding/Modifying Tooltips
- **Score breakdown tooltips** (warning, N/A, Great Job): Edit `WizardWrapper.js`, use `data-tooltip` attribute with class `aiq-warning-icon`, `aiq-na-info-icon`, or `aiq-max-score-icon`. CSS in `style.css`.
- **Matrix item tooltips**: Edit `ImpactComplexityMatrix.js`, modify tooltip content in `getCellContent()`. CSS in the `<style jsx>` block.

### Styling Changes
Edit `src/style.css`:
- `.aiq-step-item` - Tab styling
- `.aiq-question-block` - Question card styling
- `.aiq-results-container` - Results page layout
- `.aiq-warning-icon`, `.aiq-na-info-icon`, `.aiq-max-score-icon` - Score breakdown tooltips
- `.aiq-download-menu` / `.aiq-download-option` - Download dropdown
- `.aiq-modal-*` - Marketo modal styles

## Known Considerations
1. Component weights within each dimension should sum to ~1.0
2. N/A questions should be excluded from both numerator and denominator
3. MITRE's original tool has some edge case bugs around fully N/A sections
4. Build size warnings are expected (>244KB) due to PDF generation libraries
5. Section colors must be kept in sync between `WizardWrapper.js` (headers) and `ImpactComplexityMatrix.js` (matrix items + key)
6. Matrix tooltips use `<style jsx>` inside the component; score breakdown tooltips use `style.css`
7. The `data-tooltip` CSS pattern does not support HTML rendering — content is plain text only

## Dependencies
- @wordpress/scripts - Build toolchain
- react, react-dom - UI framework
- chart.js, react-chartjs-2 - Radar chart
- html2canvas - PDF screenshot capture
- jspdf - PDF generation
